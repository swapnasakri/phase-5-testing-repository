package testNGScripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Snippet {
	WebDriver driver;
	    
	    @BeforeClass
	    public void openBrowser()
	    {
	        driver = new ChromeDriver();
	        
	        driver.manage().window().maximize();
	        
	        driver.manage().deleteAllCookies();
	        
	        driver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
	        
	        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	        
	        driver.get("https://www.ironspider.ca/forms/dropdowns.htm");
	        
	    }
	
	@Test(priority='1')
	    public void dropdown() throws InterruptedException
	    {
	       Select dd = new Select(driver.findElement(By.xpath("//select[@name='coffee']")));
	        
	        
	        dd.selectByValue("black"); // black option
	        
	        Thread.sleep(2000);
	    }
	    
	
	@Test(priority='2')
	    public void checkbox() throws InterruptedException
	    {
	        driver.navigate().to("https://www.ironspider.ca/forms/checkradio.htm");
	        
	        driver.findElement(By.xpath("//input[@value='red']")).click();
	        
	        Thread.sleep(1500);
	        
	        driver.findElement(By.xpath("(//input[starts-with(@type,'check')])[3]")).click();
	        
	        
	        Thread.sleep(1500);
	        
	    }
}

