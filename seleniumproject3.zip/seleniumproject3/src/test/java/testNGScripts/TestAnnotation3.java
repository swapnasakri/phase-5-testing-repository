package testNGScripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestAnnotation3 {
	WebDriver driver;
	
	@BeforeClass
	public void StartBrowser() {
 driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://www.google.com/");
	    }
	    
	@Test
	public void Googlepage() {
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("appium Test");
	}
	    @AfterClass
	    public void closebrowser()
	    {
	        driver.close();
	    }
	

}
