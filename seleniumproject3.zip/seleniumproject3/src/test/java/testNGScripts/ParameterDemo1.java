package testNGScripts;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ParameterDemo1 {
	@Parameters()
	@Test
	public void method1(String parameter1) {
		
		
	}

}
