package seleniumproject3Day1;

public class ClassnamelocatorDemo {

}
