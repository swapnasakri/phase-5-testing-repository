package seleniumproject3Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PartiallinkedDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		

		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://en.wikipedia.org/wiki/Main_Page");
		
		
		
		driver.findElement(By.partialLinkText("Tercentery half")).click();
	}

}
