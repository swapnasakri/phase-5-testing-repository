package seleniumproject3Day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigationmethods {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver =new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		
		String title1=driver.getTitle();//get the title 
		System.out.println("the title of the page 1 is : "  +title1);
		
		//navigate to a new webpage
		driver.navigate().to("https://www.selenium.dev/downloads/");
		
		String title=driver.getTitle();//get the title 
		System.out.println("the title of the page 2 is : "  +title);
		//method to navigate back to previous webpage
		
		driver.navigate().back();
		
		//fetch the url of the page
		Thread.sleep(1500);
		
		String URL=driver.getCurrentUrl();
		System.out.println("the URL of the page navigated back is"+URL);
		
		
		
		driver.navigate().forward();
		
		Thread.sleep(1500);
		String URL2=driver.getCurrentUrl();
		
		System.out.println("the URL of the page navigated back is"+URL2);
		
		driver.close();
		
		}

}
