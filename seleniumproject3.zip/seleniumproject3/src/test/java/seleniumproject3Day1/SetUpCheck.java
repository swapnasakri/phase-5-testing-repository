package seleniumproject3Day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SetUpCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		// open a URL on the browser :get("url of webpage")
		driver.get("https://www.wikipedia.org/");
		// maximize the window browser
		driver.manage().window().maximize();
		
		//delete all cokies of the browser deleteallcookies
		driver.manage().deleteAllCookies();
		
		//open the url on browser
		driver.get("https://www.wikipedia.org/");
		
		//close the session
		driver.close();

	}

}
