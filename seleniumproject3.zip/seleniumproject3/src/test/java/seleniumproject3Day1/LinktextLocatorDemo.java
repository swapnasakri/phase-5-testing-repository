package seleniumproject3Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinktextLocatorDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://en.wikipedia.org/wiki/Main_Page");
		
		//use linkTest locator to click the link
		
		
		
		//click on link contents
		driver.findElement(By.linkText("Contents")).click();
		
		//it open a new page,fetch and print the title
		Thread.sleep(1500);
		
		String title=driver.getTitle();
		System.out.println("title of clicked linked page" +title);
		
		//click on next link
		driver.findElement(By.linkText("About Wikipedia")).click();
		
		Thread.sleep(1500);
		
		String title2=driver.getTitle();
		System.out.println("title of second clicked linked page" +title2);
		
		//Navigate back
		driver.navigate().back();
		Thread.sleep(1000);
		
		//navigate forward
		driver.navigate().forward();
		
		

	}

}
